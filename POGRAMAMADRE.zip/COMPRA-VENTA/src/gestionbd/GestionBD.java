
package gestionbd;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;


public class GestionBD {
    Connection conexion= null;
    Statement sentencia=null;
    ResultSet resultado=null;
    String NOMBREBD="JMG.sqlite";
    String URL="jdbc:sqlite:"+NOMBREBD;
    String DRIVER="org.sqlite.JDBC";
    
    public void connection(){
 try {
     conexion= DriverManager.getConnection(URL);
     if (conexion!=null) {
         System.out.println("Conectado");
     }
 }catch (SQLException ex) {
     System.err.println("No se ha podido conectar a la base de datos\n"+ex.getMessage());
 }
}
    public void crearBD(){
    try{
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        
    }catch(ClassNotFoundException | SQLException e){
        System.out.println("ERROR:"+e.getMessage());
    }
    
        System.out.println("Base de datos creada con exito!");
    }
    public void createTableClientes(){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="CREATE TABLE CLIENTES"+
                   "(ID_CLIENTE INT PRIMARY KEY NOT NULL, "+
                   "NOMBRE TEXT NOT NULL, "+
                   "FONO INT NOT NULL, "+
                   "DIRECCION TEXT NOT NULL, "+
                   "EMAIL TEXT NOT NULL)";
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        System.out.println("ERROR:"+e.getMessage());
    }
    
        System.out.println("Tabla creada con exito!");
    }
    public void createTableProductos(){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="CREATE TABLE PRODUCTOS"+
                   "(ID_PRODUCTO INT PRIMARY KEY NOT NULL, "+
                   "NOMBRE_PRODUCTO TEXT NOT NULL, "+
                   "PRECIO_PRODUCTO INT NOT NULL, "+
                   "CATEGORIA TEXT NOT NULL) ";
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        System.out.println("ERROR:"+e.getMessage());
    }
    
        System.out.println("Tabla creada con exito!");
    }
    public void createTableCompra(){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="CREATE TABLE COMPRA"+
                   "(ID_COMPRA INT PRIMARY KEY NOT NULL, "+
                   "FECHA_COMPRA TEXT NOT NULL,,"+
                   "HORA_COMPRA TEXT NOT NULL, "+
                   "ID_CLIENTE INT NOT NULL,"+
                   "ID_PRODUCTO INT NOT NULL," +
                 "FOREIGN KEY (ID_CLIENTE) REFERENCES CLIENTES(ID_CLIENTE),"+
                 "FOREIGN KEY (ID_PRODUCTO) REFERENCES PRODUCTOS(ID_PRODUCTO))";
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        System.out.println("ERROR:"+e.getMessage());
    }
    
         JOptionPane.showMessageDialog(null,"Tabla creada con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);
    }
    public void insertintoClientes(int idcliente,String nombre,int fono,String direccion,String email){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="INSERT INTO CLIENTE "
                   + "(ID_CLIENTE,NOMBRE,FONO,DIRECCION,EMAIL)"+
                   "VALUES('"+idcliente+"','"+nombre+"','"+fono+"','"+direccion+"','"+email+"')";
        sentencia.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"Datos ingresados","EXITO!",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, corroborar id de cliente","ERROR",JOptionPane.ERROR_MESSAGE);
    }
   
}
   public void DeleteCliente(int idcliente){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="DELETE FROM CLIENTE WHERE ID_CLIENTE ='"+idcliente+"'";
        sentencia.executeUpdate(sql);
        System.out.println("Datos  Eliminados");
        JOptionPane.showMessageDialog(null, "USUARIO ELIMINADO","ELIMINADO",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, Corroborar id de cliente","ERROR",JOptionPane.ERROR_MESSAGE);
    }  
} 
   public void DeleteCompra(int idcompra){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="DELETE FROM COMPRA WHERE ID_COMPRA ='"+idcompra+"'";
        sentencia.executeUpdate(sql);
        JOptionPane.showMessageDialog(null, "COMPRA ELIMINADA","ELIMINADA",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, Corroborar id de compra","ERROR",JOptionPane.ERROR_MESSAGE);
    }
    
       
}
   public void insertProducto(int idproducto,String nombre,int precio,String categoria){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="INSERT INTO LIBROS "
                   + "(ID_PRODUCTO,NOMBRE_PRODUCTO,PRECIO_PRODUCTO,CATEGORIA)"+
                   "VALUES('"+idproducto+"','"+nombre+"','"+precio+"','"+categoria+"')";
        sentencia.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"Datos ingresados","EXITO!",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, Corroborar id de producto","ERROR",JOptionPane.ERROR_MESSAGE);
    }
    
    
}

   public void DeleteProducto(int idproducto){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="DELETE FROM PRODUCTOS WHERE ID_PRODUCTO ='"+idproducto+"'";
        sentencia.executeUpdate(sql);
        System.out.println("Datos  Eliminados");
        JOptionPane.showMessageDialog(null, "PRODUCTO ELIMINADO","ELIMINADO",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, Corroborar id de producto","ERROR",JOptionPane.ERROR_MESSAGE);
    }
  
}
    public void insertCompra(int idcompra,String fecha,String hora,String idcliente,String idproducto){
    try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="INSERT INTO COMPRA "
                   + "(ID_COMPRA,FECHA,HORA,ID_CLIENTE,ID_PRODUCTO)"+
                   "VALUES('"+idcompra+"','"+fecha+"','"+hora+"','"+idcliente+"','"+idproducto+"')";
        sentencia.executeUpdate(sql);
        JOptionPane.showMessageDialog(null,"Datos ingresados","EXITO!",JOptionPane.INFORMATION_MESSAGE);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Ingrese bien los datos, Corroborar id de compra","ERROR",JOptionPane.ERROR_MESSAGE);
    }
    
        JOptionPane.showMessageDialog(null,"Datos ingresados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);
}
   public void actualizarNOMBREproducto(int idproducto,String nombre){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE PRODUCTOS SET NOMBRE_PRODUCTO ='"+nombre+"' WHERE ID_PRODUCTO = '"+idproducto+"'";
        JOptionPane.showMessageDialog(null,"Nombre de producto actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarPRECIO(int idproducto,int precio){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE PRODUCTOS SET PRECIO_PRODUCTO ='"+precio+"' WHERE ID_PRODUCTO = '"+idproducto+"'";
        JOptionPane.showMessageDialog(null,"PRECIO de producto actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarCategoria(int idproducto,String categoria){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE PRODUCTOS SET CATEGORIA ='"+categoria+"' WHERE ID_PRODUCTO = '"+idproducto+"'";
        JOptionPane.showMessageDialog(null,"CATEGORIA de producto actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarNOMBRECLIENTE(int idcliente,String nombre){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE CLIENTES SET NOMBRE ='"+nombre+"' WHERE ID_CLIENTE = '"+idcliente+"'";
        JOptionPane.showMessageDialog(null,"NOMBRE de cliente actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarfonocliente(int idcliente,int fono){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE CLIENTES SET FONO ='"+fono+"' WHERE ID_CLIENTE = '"+idcliente+"'";
        JOptionPane.showMessageDialog(null,"FONO de cliente actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
    public void actualizarDIRECCIONcliente(int idcliente,String direccion){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE CLIENTES SET DIRECCION ='"+direccion+"' WHERE ID_CLIENTE = '"+idcliente+"'";
        JOptionPane.showMessageDialog(null,"DIRECCION de cliente actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarEMAILcliente(int idcliente,String email){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE CLIENTES SET EMAIL ='"+email+"' WHERE ID_CLIENTE = '"+idcliente+"'";
        JOptionPane.showMessageDialog(null,"EMAIL de cliente actualizado","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarIDCLIENTECOMPRA(int idcompra,int idcliente){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE COMPRA SET  ID_CLIENTE='"+idcliente+"' WHERE ID_COMPRA = '"+idcompra+"'";
        JOptionPane.showMessageDialog(null,"Ha actualizado el id del cliente de la compra "+idcompra+ " correctamente","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarfechacompra(int idcompra,String fecha){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE COMPRA SET  FECHA_COMPRA='"+fecha+"' WHERE ID_COMPRA = '"+idcompra+"'";
        JOptionPane.showMessageDialog(null,"Ha actualizado la fecha de  COMPRA correctamente","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarHORACOMPRA(int idcompra,String hora){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE COMPRA SET  HORA_COMPRA='"+hora+"' WHERE ID_COMPRA = '"+idcompra+"'";
        JOptionPane.showMessageDialog(null,"Ha actualizado la HORA de  COMPRA correctamente","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void actualizarIDPRODUCTOCOMPRA(int idcompra,int idproducto){
 try{
    
        Class.forName(DRIVER);
        conexion=DriverManager.getConnection(URL);
        sentencia=conexion.createStatement();
        String sql="UPDATE COMPRA SET  ID_PRODUCTO='"+idproducto+"' WHERE ID_COMPRA = '"+idcompra+"'";
        JOptionPane.showMessageDialog(null,"Ha actualizado el id del PRODUCTO de la compra "+idcompra+ " correctamente","ACTUALIZACION",JOptionPane.INFORMATION_MESSAGE);
        sentencia.executeUpdate(sql);
        sentencia.close();
        conexion.close();
        
    }catch(ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null,"ERROR: Rellene todos los campos","ERROR",JOptionPane.ERROR_MESSAGE);
    }
        JOptionPane.showMessageDialog(null,"Datos actualizados con exito!","EXITO!",JOptionPane.INFORMATION_MESSAGE);

}
   public void mostrarClientes(JTable tablaCliente){
    try{
 
     Class.forName(DRIVER);
     conexion = DriverManager.getConnection(URL);
     sentencia = conexion.createStatement();
     String sql ="SELECT * FROM CLIENTES";
     resultado = sentencia.executeQuery(sql);
     int fila=0;
     while(resultado.next()){
     tablaCliente.setValueAt(resultado.getInt("ID_CLIENTE"),fila,0);
     tablaCliente.setValueAt(resultado.getString("NOMBRE"),fila,1);
     tablaCliente.setValueAt(resultado.getInt("FONO"),fila,2);
     tablaCliente.setValueAt(resultado.getString("DIRECCION"),fila,3);
     tablaCliente.setValueAt(resultado.getString("EMAIL"),fila,4);
     fila++;
     }
     sentencia.close();
     conexion.close();
 }catch(HeadlessException | ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null, "Error: "+e.getMessage(),"Error!",JOptionPane.ERROR_MESSAGE);


}
}
   public void mostrarProductos(JTable tablaProductos){

    
    try{
 
     Class.forName(DRIVER);
     conexion = DriverManager.getConnection(URL);
     sentencia = conexion.createStatement();
     String sql ="SELECT * FROM PRODUCTOS";
     resultado = sentencia.executeQuery(sql);
     int fila=0;
     while(resultado.next()){
     tablaProductos.setValueAt(resultado.getInt("ID_PRODUCTO"),fila,0);
     tablaProductos.setValueAt(resultado.getString("NOMBRE_PRODUCTO"),fila,1);
     tablaProductos.setValueAt(resultado.getInt("PRECIO_PRODUCTO"),fila,2);
     tablaProductos.setValueAt(resultado.getString("CATEGORIA"),fila,3);
     fila++;
     }
     
     sentencia.close();
     conexion.close();
     
     
 }catch(HeadlessException | ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null, "Error: "+e.getMessage(),"Error!",JOptionPane.ERROR_MESSAGE);


}
}
   public void mostrarCompra(JTable tablaCompra){

    
    try{
 
     Class.forName(DRIVER);
     conexion = DriverManager.getConnection(URL);
     sentencia = conexion.createStatement();
     String sql ="SELECT * FROM PRESTAMOS";
     resultado = sentencia.executeQuery(sql);
     int fila=0;
     while(resultado.next()){
     tablaCompra.setValueAt(resultado.getInt("ID_COMPRA"),fila,0);
     tablaCompra.setValueAt(resultado.getString("FECHA_COMPRA"),fila,1);
     tablaCompra.setValueAt(resultado.getString("HORA_COMPRA"),fila,2);
     tablaCompra.setValueAt(resultado.getInt("ID_CLIENTE"),fila,3);
     tablaCompra.setValueAt(resultado.getInt("ID_PRODUCTO"),fila,4);
     fila++;
     }
    
     sentencia.close();
     conexion.close();
     
     
 }catch(HeadlessException | ClassNotFoundException | SQLException e){
        JOptionPane.showMessageDialog(null, "Error: "+e.getMessage(),"Error!",JOptionPane.ERROR_MESSAGE);


}
}
}
